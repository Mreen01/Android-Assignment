package com.laurentdarl.recyclerview

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.laurentdarl.recyclerview.databinding.ActivityMainBinding
import com.laurentdarl.recyclerview.databinding.SchoolsBinding

class SchoolAdapter(var context: Context, var schools: List<Student>): RecyclerView.Adapter<SchoolAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = SchoolsBinding.inflate(LayoutInflater.from(parent.context))
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val schools = schools[position]
        holder.bind(schools)
    }

    override fun getItemCount(): Int {
      return schools.size
    }


    class ViewHolder(var binding: SchoolsBinding): RecyclerView.ViewHolder(binding.root) {

         fun bind(schools: Student) {
             binding.imageView.setImageResource(schools.images)
             binding.name.text = schools.name
             binding.place.text = schools.lastName
         }
    }
}