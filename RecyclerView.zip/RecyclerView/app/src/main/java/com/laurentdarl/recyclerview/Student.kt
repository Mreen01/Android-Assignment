package com.laurentdarl.recyclerview

data class Student (
    var images: Int,
    var name: String,
    var lastName: String
        )

